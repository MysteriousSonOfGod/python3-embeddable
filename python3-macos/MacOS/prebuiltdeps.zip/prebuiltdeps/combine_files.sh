lipo -create ../gettext_x86_64/lib/libasprintf.a ../gettext_arm64/lib/libasprintf.a -output lib/libasprintf.a
lipo -create ../gettext_x86_64/lib/libgettextpo.a ../gettext_arm64/lib/libgettextpo.a -output lib/libgettextpo.a
lipo -create ../gettext_x86_64/lib/libintl.a ../gettext_arm64/lib/libintl.a -output lib/libintl.a
lipo -create ../gettext_x86_64/lib/libtextstyle.a ../gettext_arm64/lib/libtextstyle.a -output lib/libtextstyle.a

lipo -create ../gettext_x86_64/lib/libasprintf.0.dylib ../gettext_arm64/lib/libasprintf.0.dylib -output lib/libasprintf.0.dylib	-create
lipo -create ../gettext_x86_64/lib/libgettextlib.dylib ../gettext_arm64/lib/libgettextlib.dylib -output lib/libgettextlib.dylib	-create
lipo -create ../gettext_x86_64/lib/libgettextsrc-0.21.dylib ../gettext_arm64/lib/libgettextsrc-0.21.dylib -output lib/libgettextsrc-0.21.dylib -create
lipo -create ../gettext_x86_64/lib/libintl.dylib ../gettext_arm64/lib/libintl.dylib -output lib/libintl.dylib -create
lipo -create ../gettext_x86_64/lib/libasprintf.dylib ../gettext_arm64/lib/libasprintf.dylib -output lib/libasprintf.dylib -create
lipo -create ../gettext_x86_64/lib/libgettextpo.0.dylib ../gettext_arm64/lib/libgettextpo.0.dylib -output lib/libgettextpo.0.dylib	-create
lipo -create ../gettext_x86_64/lib/libgettextsrc.dylib ../gettext_arm64/lib/libgettextsrc.dylib -output lib/libgettextsrc.dylib	-create
lipo -create ../gettext_x86_64/lib/libtextstyle.0.dylib ../gettext_arm64/lib/libtextstyle.0.dylib -output lib/libtextstyle.0.dylib	-create
lipo -create ../gettext_x86_64/lib/libgettextlib-0.21.dylib ../gettext_arm64/lib/libgettextlib-0.21.dylib -output lib/libgettextlib-0.21.dylib -create
lipo -create ../gettext_x86_64/lib/libgettextpo.dylib ../gettext_arm64/lib/libgettextpo.dylib -output lib/libgettextpo.dylib -create
lipo -create ../gettext_x86_64/lib/libintl.8.dylib ../gettext_arm64/lib/libintl.8.dylib -output lib/libintl.8.dylib	-create
lipo -create ../gettext_x86_64/lib/libtextstyle.dylib ../gettext_arm64/lib/libtextstyle.dylib -output lib/libtextstyle.dylib -create